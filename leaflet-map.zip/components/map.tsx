"use client"

import { useEffect } from "react"
import { MapContainer, TileLayer, Marker, Popup, CircleMarker } from "react-leaflet"
import L from "leaflet"
import "leaflet/dist/leaflet.css"
import { Radio, Plane, MapPin } from "lucide-react"
import type { NewsItem, AircraftData, CellTowerData } from "@/lib/types"

// Fix Leaflet icon issues
const fixLeafletIcons = () => {
  delete L.Icon.Default.prototype._getIconUrl
  L.Icon.Default.mergeOptions({
    iconRetinaUrl: "/marker-icon-2x.png",
    iconUrl: "/marker-icon.png",
    shadowUrl: "/marker-shadow.png",
  })
}

// Custom aircraft icon
const createAircraftIcon = (heading: number) => {
  return L.divIcon({
    html: `<div style="transform: rotate(${heading}deg);">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="#22c55e" strokeWidth="2">
              <path d="M22 12L3 20l3.5-8L3 4l19 8z" fill="#22c55e" stroke="#22c55e"/>
            </svg>
           </div>`,
    className: "",
    iconSize: [24, 24],
    iconAnchor: [12, 12],
  })
}

// Custom cell tower icon
const cellTowerIcon = L.divIcon({
  html: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="#ef4444" strokeWidth="2">
          <path d="M12 2v20M4 4l16 16M4 20L20 4M8 12h8" stroke="#ef4444"/>
          <circle cx="12" cy="12" r="10" stroke="#ef4444" fill="rgba(239, 68, 68, 0.2)"/>
        </svg>`,
  className: "",
  iconSize: [24, 24],
  iconAnchor: [12, 12],
})

// Custom news marker component
function NewsCircles({ data }: { data: NewsItem[] }) {
  return (
    <>
      {data.map((item) => (
        <CircleMarker
          key={`news-heat-${item.id}`}
          center={[item.lat, item.lng]}
          radius={15}
          fillColor="#3b82f6"
          color="#2563eb"
          weight={1}
          opacity={0.6}
          fillOpacity={0.4}
        >
          <Popup>
            <div>
              <h3 className="font-medium">{item.title}</h3>
              <p className="text-sm">{item.description}</p>
              <p className="text-xs mt-1">Source: {item.source}</p>
              <div className="flex items-center mt-2 text-xs text-blue-600">
                <Radio className="h-3 w-3 mr-1" />
                <span>News Event</span>
              </div>
            </div>
          </Popup>
        </CircleMarker>
      ))}
    </>
  )
}

interface MapProps {
  showNews: boolean
  showAircraft: boolean
  showCellTowers: boolean
  newsData: NewsItem[]
  aircraftData: AircraftData[]
  cellTowerData: CellTowerData[]
}

export default function Map({
  showNews,
  showAircraft,
  showCellTowers,
  newsData,
  aircraftData,
  cellTowerData,
}: MapProps) {
  useEffect(() => {
    // This is needed to fix the marker icon issues with webpack
    fixLeafletIcons()
  }, [])

  return (
    <MapContainer center={[40.7128, -74.006]} zoom={12} style={{ height: "100%", width: "100%" }}>
      <TileLayer
        attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
      />

      {/* News Heat Circles */}
      {showNews && <NewsCircles data={newsData} />}

      {/* Aircraft Markers */}
      {showAircraft &&
        aircraftData.map((item) => (
          <Marker
            key={`aircraft-${item.id}`}
            position={[item.latitude, item.longitude]}
            icon={createAircraftIcon(item.heading)}
          >
            <Popup>
              <div>
                <h3 className="font-medium">{item.callsign}</h3>
                <p className="text-sm">Altitude: {item.altitude}</p>
                <p className="text-sm">Speed: {item.velocity}</p>
                <p className="text-sm">Origin: {item.origin_country}</p>
                <div className="flex items-center mt-2 text-xs text-green-600">
                  <Plane className="h-3 w-3 mr-1" />
                  <span>Aircraft</span>
                </div>
              </div>
            </Popup>
          </Marker>
        ))}

      {/* Cell Tower Markers */}
      {showCellTowers &&
        cellTowerData.map((item) => (
          <Marker key={`tower-${item.id}`} position={[item.lat, item.lng]} icon={cellTowerIcon}>
            <Popup>
              <div>
                <h3 className="font-medium">{item.name}</h3>
                <p className="text-sm">Provider: {item.provider}</p>
                <p className="text-sm">Type: {item.type}</p>
                <div className="flex items-center mt-2 text-xs text-red-600">
                  <MapPin className="h-3 w-3 mr-1" />
                  <span>Cell Tower</span>
                </div>
              </div>
            </Popup>
          </Marker>
        ))}
    </MapContainer>
  )
}
