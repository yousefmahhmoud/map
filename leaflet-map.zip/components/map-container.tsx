"use client"

import type React from "react"

import { useState, useEffect } from "react"
import dynamic from "next/dynamic"
import { Layers, Radio, Plane, MapPin, AlertCircle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { Toggle } from "@/components/ui/toggle"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useToast } from "@/hooks/use-toast"
import { parseCSV, parseKML, parseJSON } from "@/lib/file-parsers"
import type { NewsItem, AircraftData, CellTowerData } from "@/lib/types"

// Dynamically import the Map component to avoid SSR issues with Leaflet
const Map = dynamic(() => import("@/components/map"), {
  ssr: false,
  loading: () => (
    <div className="w-full h-[calc(100vh-64px)] flex items-center justify-center bg-muted">
      <p className="text-muted-foreground">Loading map...</p>
    </div>
  ),
})

export default function MapContainer() {
  const { toast } = useToast()
  const [activeTab, setActiveTab] = useState("layers")
  const [showNews, setShowNews] = useState(true)
  const [showAircraft, setShowAircraft] = useState(true)
  const [showCellTowers, setShowCellTowers] = useState(true)

  // Data states
  const [newsData, setNewsData] = useState<NewsItem[]>([])
  const [aircraftData, setAircraftData] = useState<AircraftData[]>([])
  const [cellTowerData, setCellTowerData] = useState<CellTowerData[]>([])

  // Loading states
  const [newsLoading, setNewsLoading] = useState(true)
  const [aircraftLoading, setAircraftLoading] = useState(true)

  // Error states
  const [newsError, setNewsError] = useState<string | null>(null)
  const [aircraftError, setAircraftError] = useState<string | null>(null)

  // Fetch news data
  useEffect(() => {
    async function fetchNews() {
      try {
        setNewsLoading(true)
        setNewsError(null)

        // Instead of making an API call that will fail, use sample data directly
        // In a production app, you would use a server-side API route to proxy the request
        // const response = await fetch("https://newsapi.org/v2/top-headlines?country=us&apiKey=YOUR_API_KEY")

        console.log("Using sample news data instead of API call")

        // Use sample data
        const sampleNewsData = [
          {
            id: 1,
            title: "Local Event",
            description: "Community gathering at the park",
            source: "Local News",
            publishedAt: "2023-04-25T14:30:00Z",
            url: "#",
            lat: 40.7128,
            lng: -74.006,
          },
          {
            id: 2,
            title: "Traffic Update",
            description: "Major delays on highway",
            source: "Traffic News",
            publishedAt: "2023-04-25T13:15:00Z",
            url: "#",
            lat: 40.7228,
            lng: -74.016,
          },
          {
            id: 3,
            title: "Weather Alert",
            description: "Thunderstorms expected tonight",
            source: "Weather Channel",
            publishedAt: "2023-04-25T12:45:00Z",
            url: "#",
            lat: 40.7328,
            lng: -74.026,
          },
          {
            id: 4,
            title: "New Store Opening",
            description: "Grand opening this weekend",
            source: "Business News",
            publishedAt: "2023-04-25T11:30:00Z",
            url: "#",
            lat: 40.7428,
            lng: -74.036,
          },
          {
            id: 5,
            title: "Sports Event",
            description: "Local team wins championship",
            source: "Sports News",
            publishedAt: "2023-04-25T10:15:00Z",
            url: "#",
            lat: 40.7528,
            lng: -74.046,
          },
          {
            id: 6,
            title: "Construction Notice",
            description: "Road work starting next week",
            source: "City News",
            publishedAt: "2023-04-25T09:00:00Z",
            url: "#",
            lat: 40.7628,
            lng: -74.056,
          },
          {
            id: 7,
            title: "School Announcement",
            description: "School closed for holiday",
            source: "Education News",
            publishedAt: "2023-04-25T08:45:00Z",
            url: "#",
            lat: 40.7728,
            lng: -74.066,
          },
          {
            id: 8,
            title: "Health Advisory",
            description: "New health clinic opening",
            source: "Health News",
            publishedAt: "2023-04-25T07:30:00Z",
            url: "#",
            lat: 40.7828,
            lng: -74.076,
          },
        ]

        setNewsData(sampleNewsData)
      } catch (error) {
        console.error("Error with news data:", error)
        setNewsError("Failed to load news data.")
      } finally {
        setNewsLoading(false)
      }
    }

    fetchNews()
  }, [])

  // Also update the aircraft data fetch to use sample data directly to avoid potential API issues
  useEffect(() => {
    async function fetchAircraft() {
      try {
        setAircraftLoading(true)
        setAircraftError(null)

        // Instead of making an API call that might fail, use sample data directly
        // const response = await fetch("https://opensky-network.org/api/states/all")

        console.log("Using sample aircraft data instead of API call")

        // Use sample data
        const sampleAircraftData = [
          {
            id: 1,
            icao24: "a1b2c3",
            callsign: "FL1001",
            origin_country: "United States",
            time_position: 1682430000,
            last_contact: 1682430060,
            longitude: -74.046,
            latitude: 40.7528,
            altitude: "31,000 ft",
            on_ground: false,
            velocity: "520 knots",
            heading: 90,
            vertical_rate: 0,
            sensors: null,
          },
          {
            id: 2,
            icao24: "d4e5f6",
            callsign: "FL1002",
            origin_country: "Canada",
            time_position: 1682430000,
            last_contact: 1682430060,
            longitude: -74.056,
            latitude: 40.7628,
            altitude: "32,000 ft",
            on_ground: false,
            velocity: "540 knots",
            heading: 180,
            vertical_rate: 0,
            sensors: null,
          },
          {
            id: 3,
            icao24: "g7h8i9",
            callsign: "FL1003",
            origin_country: "United Kingdom",
            time_position: 1682430000,
            last_contact: 1682430060,
            longitude: -74.066,
            latitude: 40.7728,
            altitude: "33,000 ft",
            on_ground: false,
            velocity: "560 knots",
            heading: 270,
            vertical_rate: 0,
            sensors: null,
          },
          {
            id: 4,
            icao24: "j0k1l2",
            callsign: "FL1004",
            origin_country: "France",
            time_position: 1682430000,
            last_contact: 1682430060,
            longitude: -74.076,
            latitude: 40.7828,
            altitude: "34,000 ft",
            on_ground: false,
            velocity: "580 knots",
            heading: 0,
            vertical_rate: 0,
            sensors: null,
          },
          {
            id: 5,
            icao24: "m3n4o5",
            callsign: "FL1005",
            origin_country: "Germany",
            time_position: 1682430000,
            last_contact: 1682430060,
            longitude: -74.086,
            latitude: 40.7928,
            altitude: "35,000 ft",
            on_ground: false,
            velocity: "600 knots",
            heading: 45,
            vertical_rate: 0,
            sensors: null,
          },
          {
            id: 6,
            icao24: "p6q7r8",
            callsign: "FL1006",
            origin_country: "Spain",
            time_position: 1682430000,
            last_contact: 1682430060,
            longitude: -74.096,
            latitude: 40.8028,
            altitude: "36,000 ft",
            on_ground: false,
            velocity: "620 knots",
            heading: 135,
            vertical_rate: 0,
            sensors: null,
          },
          {
            id: 7,
            icao24: "s9t0u1",
            callsign: "FL1007",
            origin_country: "Italy",
            time_position: 1682430000,
            last_contact: 1682430060,
            longitude: -74.106,
            latitude: 40.8128,
            altitude: "37,000 ft",
            on_ground: false,
            velocity: "640 knots",
            heading: 225,
            vertical_rate: 0,
            sensors: null,
          },
          {
            id: 8,
            icao24: "v2w3x4",
            callsign: "FL1008",
            origin_country: "Japan",
            time_position: 1682430000,
            last_contact: 1682430060,
            longitude: -74.116,
            latitude: 40.8228,
            altitude: "38,000 ft",
            on_ground: false,
            velocity: "660 knots",
            heading: 315,
            vertical_rate: 0,
            sensors: null,
          },
        ]

        setAircraftData(sampleAircraftData)
      } catch (error) {
        console.error("Error with aircraft data:", error)
        setAircraftError("Failed to load aircraft data.")
      } finally {
        setAircraftLoading(false)
      }
    }

    fetchAircraft()
  }, [])

  // Handle file upload for cell tower data
  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (!file) return

    try {
      let parsedData: CellTowerData[] = []

      if (file.name.endsWith(".csv")) {
        parsedData = await parseCSV(file)
      } else if (file.name.endsWith(".kml")) {
        parsedData = await parseKML(file)
      } else if (file.name.endsWith(".json") || file.name.endsWith(".geojson")) {
        parsedData = await parseJSON(file)
      } else {
        throw new Error("Unsupported file format. Please upload a CSV, KML, or JSON file.")
      }

      setCellTowerData(parsedData)
      toast({
        title: "File uploaded successfully",
        description: `Loaded ${parsedData.length} cell tower locations`,
      })

      // Automatically show cell towers when data is loaded
      setShowCellTowers(true)
    } catch (error) {
      console.error("Error parsing file:", error)
      toast({
        title: "Error uploading file",
        description: error instanceof Error ? error.message : "Unknown error occurred",
        variant: "destructive",
      })
    }

    // Clear the input value so the same file can be uploaded again if needed
    event.target.value = ""
  }

  return (
    <div className="flex flex-col h-screen">
      <header className="border-b">
        <div className="container flex h-16 items-center px-4 md:px-6">
          <h1 className="text-lg font-semibold">Interactive Map Dashboard</h1>
          <nav className="ml-auto flex gap-4 sm:gap-6">
            <Button variant="ghost" size="sm">
              About
            </Button>
            <Button variant="ghost" size="sm">
              Help
            </Button>
          </nav>
        </div>
      </header>

      <div className="flex flex-1 overflow-hidden">
        <div className="w-full flex flex-col md:flex-row">
          <div className="w-full md:w-3/4 h-[calc(100vh-64px)]">
            <Map
              showNews={showNews}
              showAircraft={showAircraft}
              showCellTowers={showCellTowers}
              newsData={newsData}
              aircraftData={aircraftData}
              cellTowerData={cellTowerData}
            />
          </div>

          <div className="w-full md:w-1/4 border-l">
            <Tabs value={activeTab} onValueChange={setActiveTab} className="h-full">
              <TabsList className="grid grid-cols-3 w-full">
                <TabsTrigger value="layers">
                  <Layers className="h-4 w-4 mr-2" />
                  Layers
                </TabsTrigger>
                <TabsTrigger value="news">
                  <Radio className="h-4 w-4 mr-2" />
                  News
                </TabsTrigger>
                <TabsTrigger value="data">
                  <MapPin className="h-4 w-4 mr-2" />
                  Data
                </TabsTrigger>
              </TabsList>

              <TabsContent value="layers" className="p-4 overflow-auto max-h-[calc(100vh-120px)]">
                <Card>
                  <CardHeader>
                    <CardTitle>Map Layers</CardTitle>
                    <CardDescription>Toggle visibility of different data layers</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <Radio className="h-4 w-4 text-blue-500" />
                        <span>News (Heat Map)</span>
                      </div>
                      <Toggle
                        pressed={showNews}
                        onPressedChange={setShowNews}
                        aria-label="Toggle news"
                        disabled={newsLoading || newsData.length === 0}
                      />
                    </div>

                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <Plane className="h-4 w-4 text-green-500" />
                        <span>Aircraft</span>
                      </div>
                      <Toggle
                        pressed={showAircraft}
                        onPressedChange={setShowAircraft}
                        aria-label="Toggle aircraft"
                        disabled={aircraftLoading || aircraftData.length === 0}
                      />
                    </div>

                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <MapPin className="h-4 w-4 text-red-500" />
                        <span>Cell Towers</span>
                      </div>
                      <Toggle
                        pressed={showCellTowers}
                        onPressedChange={setShowCellTowers}
                        aria-label="Toggle cell towers"
                        disabled={cellTowerData.length === 0}
                      />
                    </div>
                  </CardContent>
                  <CardFooter className="flex flex-col items-start">
                    <div className="w-full space-y-2">
                      <Label htmlFor="file-upload">Upload Cell Tower Data (CSV, KML, or JSON)</Label>
                      <Input
                        id="file-upload"
                        type="file"
                        accept=".csv,.kml,.json,.geojson"
                        onChange={handleFileUpload}
                      />
                      <p className="text-xs text-muted-foreground">
                        Upload a file containing cell tower locations with lat/lon coordinates
                      </p>
                    </div>
                  </CardFooter>
                </Card>

                {(newsError || aircraftError) && (
                  <Alert variant="destructive" className="mt-4">
                    <AlertCircle className="h-4 w-4" />
                    <AlertTitle>Error</AlertTitle>
                    <AlertDescription>
                      {newsError && <p>{newsError}</p>}
                      {aircraftError && <p>{aircraftError}</p>}
                    </AlertDescription>
                  </Alert>
                )}
              </TabsContent>

              <TabsContent value="news" className="p-4 overflow-auto max-h-[calc(100vh-120px)]">
                <Card>
                  <CardHeader>
                    <CardTitle>Latest News</CardTitle>
                    <CardDescription>Recent news events on the map</CardDescription>
                  </CardHeader>
                  <CardContent>
                    {newsLoading ? (
                      <div className="py-4 text-center">
                        <p className="text-muted-foreground">Loading news data...</p>
                      </div>
                    ) : newsData.length === 0 ? (
                      <div className="py-4 text-center">
                        <p className="text-muted-foreground">No news data available</p>
                      </div>
                    ) : (
                      <div className="space-y-4">
                        {newsData.map((item) => (
                          <div key={item.id} className="border-b pb-4 last:border-0">
                            <h3 className="font-medium">{item.title}</h3>
                            <p className="text-sm text-muted-foreground">{item.description}</p>
                            <div className="flex justify-between items-center mt-2">
                              <p className="text-xs text-muted-foreground">Source: {item.source}</p>
                              <p className="text-xs text-muted-foreground">
                                {new Date(item.publishedAt).toLocaleString()}
                              </p>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="data" className="p-4 overflow-auto max-h-[calc(100vh-120px)]">
                <Card className="mb-4">
                  <CardHeader>
                    <CardTitle>Aircraft Data</CardTitle>
                    <CardDescription>Active aircraft in the area</CardDescription>
                  </CardHeader>
                  <CardContent>
                    {aircraftLoading ? (
                      <div className="py-4 text-center">
                        <p className="text-muted-foreground">Loading aircraft data...</p>
                      </div>
                    ) : aircraftData.length === 0 ? (
                      <div className="py-4 text-center">
                        <p className="text-muted-foreground">No aircraft data available</p>
                      </div>
                    ) : (
                      <div className="space-y-2">
                        {aircraftData.map((item) => (
                          <div key={item.id} className="border-b pb-2 last:border-0">
                            <div className="flex justify-between">
                              <span className="font-medium">{item.callsign}</span>
                              <span className="text-sm">{item.altitude}</span>
                            </div>
                            <p className="text-xs text-muted-foreground">Speed: {item.velocity}</p>
                            <p className="text-xs text-muted-foreground">Origin: {item.origin_country}</p>
                          </div>
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Cell Tower Data</CardTitle>
                    <CardDescription>Cell towers in the area</CardDescription>
                  </CardHeader>
                  <CardContent>
                    {cellTowerData.length === 0 ? (
                      <div className="py-4 text-center">
                        <p className="text-muted-foreground">No cell tower data available</p>
                        <p className="text-xs text-muted-foreground mt-2">
                          Upload a CSV, KML, or JSON file in the Layers tab
                        </p>
                      </div>
                    ) : (
                      <div className="space-y-2">
                        {cellTowerData.map((item) => (
                          <div key={item.id} className="border-b pb-2 last:border-0">
                            <div className="flex justify-between">
                              <span className="font-medium">{item.name}</span>
                              <span className="text-sm">{item.type}</span>
                            </div>
                            <p className="text-xs text-muted-foreground">Provider: {item.provider}</p>
                            <p className="text-xs text-muted-foreground">
                              Location: {item.lat.toFixed(4)}, {item.lng.toFixed(4)}
                            </p>
                          </div>
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>
    </div>
  )
}
