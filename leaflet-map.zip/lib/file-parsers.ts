import type { CellTowerData } from "./types"

// Parse CSV file
export async function parseCSV(file: File): Promise<CellTowerData[]> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader()

    reader.onload = (event) => {
      try {
        const csvData = event.target?.result as string
        if (!csvData) {
          throw new Error("Failed to read CSV file")
        }

        // Split the CSV into lines
        const lines = csvData.split("\n")

        // Get headers from the first line
        const headers = lines[0].split(",").map((header) => header.trim())

        // Check if required columns exist
        const latIndex = headers.findIndex((h) => h.toLowerCase() === "lat" || h.toLowerCase() === "latitude")

        const lngIndex = headers.findIndex(
          (h) => h.toLowerCase() === "lng" || h.toLowerCase() === "lon" || h.toLowerCase() === "longitude",
        )

        const nameIndex = headers.findIndex(
          (h) => h.toLowerCase() === "name" || h.toLowerCase() === "tower_name" || h.toLowerCase() === "site_name",
        )

        const providerIndex = headers.findIndex(
          (h) => h.toLowerCase() === "provider" || h.toLowerCase() === "operator" || h.toLowerCase() === "carrier",
        )

        const typeIndex = headers.findIndex(
          (h) => h.toLowerCase() === "type" || h.toLowerCase() === "technology" || h.toLowerCase() === "network_type",
        )

        if (latIndex === -1 || lngIndex === -1) {
          throw new Error("CSV file must contain latitude and longitude columns")
        }

        // Parse the data rows
        const towers: CellTowerData[] = []

        for (let i = 1; i < lines.length; i++) {
          const line = lines[i].trim()
          if (!line) continue // Skip empty lines

          const values = line.split(",").map((value) => value.trim())

          const lat = Number.parseFloat(values[latIndex])
          const lng = Number.parseFloat(values[lngIndex])

          if (isNaN(lat) || isNaN(lng)) {
            console.warn(`Skipping row ${i} due to invalid coordinates`)
            continue
          }

          towers.push({
            id: i,
            name: nameIndex !== -1 ? values[nameIndex] : `Tower ${i}`,
            provider: providerIndex !== -1 ? values[providerIndex] : "Unknown",
            type: typeIndex !== -1 ? values[typeIndex] : "Unknown",
            lat,
            lng,
          })
        }

        resolve(towers)
      } catch (error) {
        reject(error)
      }
    }

    reader.onerror = () => {
      reject(new Error("Error reading the CSV file"))
    }

    reader.readAsText(file)
  })
}

// Parse KML file
export async function parseKML(file: File): Promise<CellTowerData[]> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader()

    reader.onload = (event) => {
      try {
        const kmlData = event.target?.result as string
        if (!kmlData) {
          throw new Error("Failed to read KML file")
        }

        // Parse the KML XML
        const parser = new DOMParser()
        const xmlDoc = parser.parseFromString(kmlData, "text/xml")

        // Find all placemarks in the KML
        const placemarks = xmlDoc.getElementsByTagName("Placemark")

        if (placemarks.length === 0) {
          throw new Error("No placemarks found in the KML file")
        }

        const towers: CellTowerData[] = []

        for (let i = 0; i < placemarks.length; i++) {
          const placemark = placemarks[i]

          // Get the name
          const nameElement = placemark.getElementsByTagName("name")[0]
          const name = nameElement ? nameElement.textContent || `Tower ${i + 1}` : `Tower ${i + 1}`

          // Get coordinates
          const coordinates = placemark.getElementsByTagName("coordinates")[0]

          if (!coordinates || !coordinates.textContent) {
            console.warn(`Skipping placemark ${i} due to missing coordinates`)
            continue
          }

          // KML coordinates are in format: longitude,latitude,altitude
          const coords = coordinates.textContent.trim().split(",")
          const lng = Number.parseFloat(coords[0])
          const lat = Number.parseFloat(coords[1])

          if (isNaN(lat) || isNaN(lng)) {
            console.warn(`Skipping placemark ${i} due to invalid coordinates`)
            continue
          }

          // Try to extract additional data from description or ExtendedData
          let provider = "Unknown"
          let type = "Unknown"

          // Check for description
          const description = placemark.getElementsByTagName("description")[0]
          if (description && description.textContent) {
            const descText = description.textContent

            // Try to extract provider and type from description text
            if (descText.includes("Provider:")) {
              const providerMatch = descText.match(/Provider:\s*([^,\n]+)/)
              if (providerMatch && providerMatch[1]) {
                provider = providerMatch[1].trim()
              }
            }

            if (descText.includes("Type:")) {
              const typeMatch = descText.match(/Type:\s*([^,\n]+)/)
              if (typeMatch && typeMatch[1]) {
                type = typeMatch[1].trim()
              }
            }
          }

          // Check for ExtendedData
          const extendedData = placemark.getElementsByTagName("ExtendedData")[0]
          if (extendedData) {
            const dataElements = extendedData.getElementsByTagName("Data")

            for (let j = 0; j < dataElements.length; j++) {
              const dataElement = dataElements[j]
              const dataName = dataElement.getAttribute("name")?.toLowerCase()
              const value = dataElement.getElementsByTagName("value")[0]?.textContent

              if (value) {
                if (dataName === "provider" || dataName === "operator" || dataName === "carrier") {
                  provider = value
                } else if (dataName === "type" || dataName === "technology" || dataName === "network_type") {
                  type = value
                }
              }
            }
          }

          towers.push({
            id: i + 1,
            name,
            provider,
            type,
            lat,
            lng,
          })
        }

        resolve(towers)
      } catch (error) {
        reject(error)
      }
    }

    reader.onerror = () => {
      reject(new Error("Error reading the KML file"))
    }

    reader.readAsText(file)
  })
}

// Parse JSON file
export async function parseJSON(file: File): Promise<CellTowerData[]> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader()

    reader.onload = (event) => {
      try {
        const jsonData = event.target?.result as string
        if (!jsonData) {
          throw new Error("Failed to read JSON file")
        }

        // Parse the JSON
        const data = JSON.parse(jsonData)

        // Handle different JSON structures
        let towers: CellTowerData[] = []

        // If data is an array
        if (Array.isArray(data)) {
          towers = data
            .map((item, index) => {
              // Check for lat/lon or latitude/longitude
              const lat = item.lat !== undefined ? item.lat : item.latitude
              const lng = item.lon !== undefined ? item.lon : item.lng !== undefined ? item.lng : item.longitude

              if (lat === undefined || lng === undefined) {
                console.warn(`Skipping item ${index} due to missing coordinates`)
                return null
              }

              return {
                id: index + 1,
                name: item.name || item.tower_name || item.site_name || `Tower ${index + 1}`,
                provider: item.provider || item.operator || item.carrier || "Unknown",
                type: item.type || item.technology || item.network_type || "Unknown",
                lat: Number(lat),
                lng: Number(lng),
              }
            })
            .filter(Boolean) as CellTowerData[]
        }
        // If data has a features array (GeoJSON)
        else if (data.features && Array.isArray(data.features)) {
          towers = data.features
            .map((feature: any, index: number) => {
              if (!feature.geometry || feature.geometry.type !== "Point") {
                console.warn(`Skipping feature ${index} due to missing or invalid geometry`)
                return null
              }

              // GeoJSON coordinates are [longitude, latitude]
              const [lng, lat] = feature.geometry.coordinates

              if (lat === undefined || lng === undefined) {
                console.warn(`Skipping feature ${index} due to missing coordinates`)
                return null
              }

              const properties = feature.properties || {}

              return {
                id: index + 1,
                name: properties.name || properties.tower_name || properties.site_name || `Tower ${index + 1}`,
                provider: properties.provider || properties.operator || properties.carrier || "Unknown",
                type: properties.type || properties.technology || properties.network_type || "Unknown",
                lat: Number(lat),
                lng: Number(lng),
              }
            })
            .filter(Boolean) as CellTowerData[]
        } else {
          throw new Error("Unsupported JSON format. Expected an array or GeoJSON format.")
        }

        if (towers.length === 0) {
          throw new Error("No valid tower data found in the JSON file")
        }

        resolve(towers)
      } catch (error) {
        reject(error)
      }
    }

    reader.onerror = () => {
      reject(new Error("Error reading the JSON file"))
    }

    reader.readAsText(file)
  })
}
