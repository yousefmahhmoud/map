// News data type
export interface NewsItem {
  id: number
  title: string
  description: string
  source: string
  publishedAt: string
  url: string
  lat: number
  lng: number
}

// Aircraft data type
export interface AircraftData {
  id: number
  icao24: string
  callsign: string
  origin_country: string
  time_position: number
  last_contact: number
  longitude: number
  latitude: number
  altitude: string
  on_ground: boolean
  velocity: string
  heading: number
  vertical_rate: number | null
  sensors: any
}

// Cell tower data type
export interface CellTowerData {
  id: number
  name: string
  provider: string
  type: string
  lat: number
  lng: number
  height?: number
  frequency?: string
  technology?: string
}
